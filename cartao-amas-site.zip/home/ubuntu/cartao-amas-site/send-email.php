<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Coleta e sanitiza os dados do formulário
    $nomeCompleto = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $emailCliente = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING);
    $assuntoSelecionado = filter_input(INPUT_POST, 'assunto', FILTER_SANITIZE_STRING);
    $mensagemCliente = filter_input(INPUT_POST, 'mensagem', FILTER_SANITIZE_STRING);

    // Validação básica
    if (empty($nomeCompleto) || !filter_var($emailCliente, FILTER_VALIDATE_EMAIL) || empty($telefone) || empty($assuntoSelecionado) || empty($mensagemCliente)) {
        // Redireciona de volta para o formulário com uma mensagem de erro
        header("Location: fale-conosco.html?status=erro_preenchimento");
        exit;
    }

    // Destinatário
    $destinatario = "faleconosco@cartaoamas.com.br";

    // Assunto do E-mail
    $partesNome = explode(' ', trim($nomeCompleto));
    $primeirosNomes = $partesNome[0] . (isset($partesNome[1]) ? ' ' . $partesNome[1] : '');
    $assuntoEmail = "Fale Conosco - " . $primeirosNomes;

    // Corpo do E-mail
    $corpoEmail = "Vim do site Cartão Amas e tenho uma dúvida!\n\n";
    $corpoEmail .= "Dados do Cliente:\n";
    $corpoEmail .= "Nome: " . $nomeCompleto . "\n";
    $corpoEmail .= "Email: " . $emailCliente . "\n";
    $corpoEmail .= "Telefone: " . $telefone . "\n";
    $corpoEmail .= "Assunto Selecionado: " . $assuntoSelecionado . "\n\n";
    $corpoEmail .= "Mensagem:\n" . $mensagemCliente . "\n";

    // Cabeçalhos do E-mail
    $remetente = "nao-responda@cartaoamas.com.br";
    $headers = "From: Cartão Amas <" . $remetente . ">\r\n"; // Nome amigável para o remetente
    $headers .= "Reply-To: " . $emailCliente . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();

    // Tenta enviar o e-mail
    // A função mail() pode não funcionar confiavelmente com Gmail sem configuração SMTP adequada no servidor.
    // Recomenda-se usar PHPMailer para envio via SMTP do Gmail.
    if (mail($destinatario, $assuntoEmail, $corpoEmail, $headers)) {
        header("Location: fale-conosco.html?status=sucesso");
        exit;
    } else {
        header("Location: fale-conosco.html?status=erro_envio");
        exit;
    }
} else {
    // Se não for POST, redireciona ou exibe erro
    header("Location: fale-conosco.html?status=erro_metodo");
    exit;
}

/*
Nota Importante sobre o envio de e-mails com Gmail:

A função mail() do PHP depende da configuração do servidor de e-mail local (ex: sendmail, Postfix).
Para enviar e-mails de forma confiável através de um servidor Gmail, é ALTAMENTE RECOMENDÁVEL
utilizar uma biblioteca como o PHPMailer com autenticação SMTP (usuário e senha do Gmail).

Configurar o Gmail para permitir "Acesso a app menos seguro" (não recomendado por questões de segurança)
ou gerar uma "Senha de app" específica para o seu site pode ser necessário se o servidor não estiver
corretamente configurado para retransmitir e-mails ou se a função mail() não for suficiente.

Para usar PHPMailer, você precisaria:
1. Baixar a biblioteca PHPMailer (https://github.com/PHPMailer/PHPMailer).
2. Incluir os arquivos da biblioteca no seu projeto.
3. Adaptar o código abaixo:

-- Exemplo com PHPMailer (COMENTADO PARA NÃO QUEBRAR O SCRIPT ATUAL) --

require 'path/to/PHPMailer/src/Exception.php';
require 'path/to/PHPMailer/src/PHPMailer.php';
require 'path/to/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// $mail = new PHPMailer(true);
// try {
//     //Configurações do servidor SMTP do Gmail
//     $mail->isSMTP();
//     $mail->Host       = 'smtp.gmail.com';
//     $mail->SMTPAuth   = true;
//     $mail->Username   = 'seu-email-de-envio@gmail.com'; // E-mail do Gmail que fará o envio
//     $mail->Password   = 'sua-senha-de-app-gmail';       // Senha de app gerada no Gmail
//     $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
//     $mail->Port       = 465;
//     $mail->CharSet    = 'UTF-8';

//     //Remetente e Destinatário
//     $mail->setFrom($remetente, 'Contato Site Cartão Amas'); // Remetente (nao-responda@cartaoamas.com.br)
//     $mail->addAddress($destinatario);                     // Destinatário (faleconosco@cartaoamas.com.br)
//     $mail->addReplyTo($emailCliente, $nomeCompleto);      // E-mail de resposta para o cliente

//     //Conteúdo
//     $mail->isHTML(false); // Define e-mail como texto plano
//     $mail->Subject = $assuntoEmail;
//     $mail->Body    = $corpoEmail;

//     $mail->send();
//     header("Location: fale-conosco.html?status=sucesso_phpmailer");
//     exit;
// } catch (Exception $e) {
//     // header("Location: fale-conosco.html?status=erro_phpmailer&msg=" . urlencode($mail->ErrorInfo));
//     // Para depuração, você pode exibir o erro:
//     // echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"; 
//     // exit;
//     header("Location: fale-conosco.html?status=erro_envio_phpmailer");
//     exit;
// }

*/
?>
